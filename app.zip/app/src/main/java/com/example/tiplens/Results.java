package com.example.tiplens;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Results extends AppCompatActivity {

    Button btnBack,copyBtn;
    EditText displayText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_results);

        displayText = findViewById(R.id.textDisp);
        btnBack = findViewById(R.id.backBtn);
        copyBtn = findViewById(R.id.copyBtn);



        String dataFromMainAct = getIntent().getStringExtra("dataResults");
        displayText.setText(dataFromMainAct);


        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });

        copyBtn.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("label", displayText.getText().toString().trim());
                clipboard.setPrimaryClip(clip);
                Toast.makeText(Results.this, "Copied to clipboard.", Toast.LENGTH_SHORT).show();
            }
        });
    }



}